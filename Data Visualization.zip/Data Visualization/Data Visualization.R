#http://shinyapps.org/apps/RGraphCompendium/index.php
#http://motioninsocial.com/tufte/

##### Import Data #####
library(readxl)
my.data <- read_excel("/home/ali/Desktop/DataPlots.xlsx", sheet="Sheet1")

##### R Base Graphics #####
library(graphics)

plot(my.data$Memory,type="p")
plot(my.data$Memory,type="l")
plot(my.data$Memory,type="b")
plot(my.data$Memory,type="h")

quartzFonts(roya = c('XB Roya','XB RoyaBd','XB RoyaIt','XB RoyaBdIt'))
par(family = 'roya')

plot(my.data$Memory,type="l", xaxt="n", yaxt="n", ann=FALSE, axes=FALSE)
lines(my.data$Attention,lty="dashed",lwd=1)
axis(side=1,at=c(0,20,40,60,80,100),labels = c("۰","۲۰","۴۰","۶۰","۸۰","۱۰۰"))
axis(side=2,at=c(12,14,16,18),labels = c("۱۲","۱۴","۱۶","۱۸"))
legend("bottomleft", legend=c("Memory", "Attention"),
       lty=1:2, cex=0.8,
       title="راهنما", text.font=2, bg='lightblue')

plot(as.factor(my.data$IntentionalBias))

hist(my.data$Memory)
boxplot(my.data$Memory)

plot(Attention~Memory, data=my.data)
plot(my.data$Memory,my.data$Attention,
     main="Memory vs Attention",
     xlab="Memory",ylab="Attention")

##### ggplot2 #####
install.packages("ggplot2")
library(ggplot2)

#Scatter Plot
ggplot(data=my.data) + 
  geom_point(mapping=aes(x=Memory,y=Attention))

ggplot(data=my.data) + 
  geom_point(mapping=aes(x=Memory,y=Attention,
                         shape=IntentionalBias))

ggplot(data=my.data) + 
  geom_point(mapping=aes(x=Memory,y=Attention,
                         color=IntentionalBias))

ggplot(data=my.data) + 
  geom_point(mapping=aes(x=Memory,y=Attention,
                         color=IntentionalBias,
                         size=SpatialAbilities))

ggplot(data=my.data) + 
  geom_point(mapping=aes(x=Memory,y=Attention,
                         color=IntentionalBias,
                         size=SpatialAbilities,
                         alpha=1/2))

#Lines and Smoothers
ggplot(data=my.data) + 
  geom_line(mapping=aes(x=Memory,y=Attention))

ggplot(data=my.data) + 
  geom_line(mapping=aes(x=Memory,y=Attention)) + 
  geom_point(mapping=aes(x=Memory,y=Attention))

ggplot(data=my.data,mapping=aes(x=Memory,y=Attention)) + 
  geom_line() + 
  geom_point()

ggplot(data=my.data,mapping=aes(x=Memory,y=Attention)) + 
  geom_smooth() + 
  geom_point()

ggplot(data=my.data,mapping=aes(x=Memory,y=Attention)) + 
  geom_smooth(se=FALSE) + 
  geom_point()

#Bars and Columns
ggplot(data=my.data) +
  geom_bar(mapping=aes(x=IntentionalBias))

ggplot(data=my.data) +
  geom_bar(mapping=aes(x=IntentionalBias,color=Major))

ggplot(data=my.data) +
  geom_bar(mapping=aes(x=IntentionalBias,fill=Major))

ggplot(data=my.data) +
  geom_col(mapping=aes(x=Major,y=Attention))

#Histogram
ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory))

ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory),origin=0)

ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory),origin=0,bins=10)

ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory),origin=0,binwidth=1)

#Box Plot
ggplot(data=my.data) + 
  geom_point(mapping=aes(x=IntentionalBias,y=Memory))

ggplot(data=my.data) + 
  geom_jitter(mapping=aes(x=IntentionalBias,y=Memory))

ggplot(data=my.data) + 
  geom_boxplot(mapping=aes(x=IntentionalBias,y=Memory))

#Drawing Functions
func.parabola <- function(x) x^2 + x

ggplot(data = data.frame(x = 0), mapping = aes(x = x)) +
  stat_function(fun = func.parabola) + 
  xlim(-5,5)

#Modifying the Background
ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory)) + 
  theme(plot.background = element_rect(fill="blue"))

ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory)) + 
  theme(panel.background = element_rect(fill="blue"))

ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory)) + 
  theme(panel.background = element_blank())

ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory)) + 
  theme(panel.background = element_blank()) + 
  theme(panel.grid.major = element_line(color="grey"))

ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory)) + 
  theme(panel.background = element_blank()) + 
  theme(panel.grid.major.y = element_line(color="grey"))

#Working with Axes
ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory)) + 
  theme(panel.background = element_blank()) + 
  xlab("Memory Label") + 
  ylab("Count Label") + 
  ylim(0,15)

#Working with Legends
ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory,fill=IntentionalBias)) + 
  theme(panel.background = element_blank()) + 
  scale_fill_manual(values = c("black","grey","brown"))

ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory,fill=IntentionalBias)) + 
  theme(panel.background = element_blank()) + 
  scale_fill_manual(values = c("black","grey","brown"),
                    guide=guide_legend("Intentional Bias"))

#Using Themes
ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory,fill=IntentionalBias)) + 
  theme_bw()

ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory,fill=IntentionalBias)) + 
  theme_minimal()

ggplot(data=my.data) +
  geom_histogram(mapping=aes(x=Memory,fill=IntentionalBias)) + 
  theme_void()
