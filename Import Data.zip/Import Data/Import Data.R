#Set Working Directory
getwd()     #get working directory
setwd("C:\\Folder1\\Folder2\\Folder3")     #Windows
setwd("C:/Folder1/Folder2/Folder3")     #Windows
setwd("/Folder1/Folder2/Folder3")     #Linux and Mac
setwd(file.path("C:","Folder1","Folder2","Folder3"))

##### Import CSV File #####
my.data <- read.csv("/home/ali/Desktop/Data.csv",header=TRUE,sep=",")
str(my.data)
my.data

##### Import Table #####
my.data <- read.table("/home/ali/Desktop/Data.txt",header=TRUE)
str(my.data)
my.data

##### Import from URL #####
url <- "..."
dest <- "..."
download.file(url,dest)
my.data <- read.table(dest)

##### Import Excel Files #####
install.packages("XLConnect")
library(XLConnect)
my.data <- readWorksheetFromFile("/home/ali/Desktop/Data.xlsx",sheet=1)

install.packages("readxl")
library(readxl)
my.data <- read_excel("/home/ali/Desktop/Data.xlsx", sheet="Sheet1")
str(my.data)
my.data

##### Import Buit-In Datasets #####
library(datasets)
data(package="datasets")
data(iris)
str(iris)
iris